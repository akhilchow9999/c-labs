﻿using System;
using System.Collections.Generic;
using System.Text;
using Capgemini.GreatOutdoor.Contracts.DALContracts;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.Helpers;

namespace Capgemini.GreatOutdoor.DataAccessLayer
{/// <summary>
/// views retailer reports
/// </summary>
    public class ViewRetailerReportsDAL : ViewRetailerReportsDALBase, IDisposable
    {
        public void Dispose()
        {
           
        }
    }
}
