﻿using System;
using System.Windows;

using System.Collections.Generic;
using Capgemini.GreatOutdoor.Contracts.DALContracts;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Helpers;
using System.Data.SqlClient;
using System.Data;
/// <summary>
/// developed by sravani
/// </summary>
namespace Capgemini.GreatOutdoor.DataAccessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting admins from Admins collection.
    /// </summary>
    public class AdminDAL : AdminDALBase, IDisposable
    {
        /// <summary>
        /// Constructor for AdminDAL
        /// </summary>
        public AdminDAL()
        {
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);

        }

        /// <summary>
        /// Gets admin based on Admin email.
        /// </summary>
        /// <param name="search through Admin email">Represents Admin email to search.</param>
        /// <returns>Returns Admin object.</returns>
        public override Admin GetAdminByAdminEmailDAL(string email)
        {
            Admin matchedAdmin = null;
            //creating SqlConnection object
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);

            try
            {
                sqlConn.Open();
                //creating object of sql Command
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "TeamB.GetAdminbyEmail";
                sqlcmd.Connection = sqlConn;
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@email", email);

                //creating object of sql data reader
                SqlDataReader sqlreader = sqlcmd.ExecuteReader();

                //loading into object
                if (sqlreader.HasRows)
                {
                    while (sqlreader.Read())
                    {
                        Admin matchingAdmin = new Admin();
                        matchingAdmin.AdminID = sqlreader.GetGuid(0);
                        matchingAdmin.AdminName = sqlreader.GetString(1);
                        matchingAdmin.Email = sqlreader.GetString(2);
                        matchingAdmin.Password = sqlreader.GetString(3);
                        matchingAdmin.CreationDateTime = sqlreader.GetDateTime(4);
                        matchingAdmin.LastModifiedDateTime = sqlreader.GetDateTime(5);
                        matchedAdmin = matchingAdmin;
                    }
                }

                sqlreader.Close();
                sqlConn.Close();
            }
            catch (Exception) { throw; }




            return matchedAdmin;
        }

        /// <summary>
        /// Gets admin based on Password.
        /// </summary>
        /// <param name="email">Represents Admin's Email Address.</param>
        /// <param name="password">Represents Admin's Password.</param>
        /// <returns>Returns Admin object.</returns>
        public override Admin GetAdminByEmailAndPasswordDAL(string email, string password)
        {
            Admin matchedAdmin = null;
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);

            try
            {
                sqlConn.Open();
                //creating object of sql Command
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "TeamB.GetAdminbyEmailAndPassword";
                sqlcmd.Connection = sqlConn;
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@email", email);
                sqlcmd.Parameters.AddWithValue("@password", password);


                //creating object of sql data reader
                SqlDataReader sqlreader = sqlcmd.ExecuteReader();

                //loading into object
                if (sqlreader.HasRows)
                {
                    while (sqlreader.Read())
                    {
                        Admin matchingAdmin = new Admin();

                        matchingAdmin.AdminID = sqlreader.GetGuid(0);
                        matchingAdmin.AdminName = sqlreader.GetString(1);
                        matchingAdmin.Email = sqlreader.GetString(2);
                        matchingAdmin.Password = sqlreader.GetString(3);
                        matchingAdmin.CreationDateTime = sqlreader.GetDateTime(4);
                        matchingAdmin.LastModifiedDateTime = sqlreader.GetDateTime(5);
                        matchedAdmin = matchingAdmin;

                    }
                }

                sqlreader.Close();
                sqlConn.Close();

            }
            catch (Exception)
            {
                throw;
            }
            return matchedAdmin;
        }

        /// <summary>
        /// Updates admin based on Admin Email.
        /// </summary>
        /// <param name="updateAdmin">Represents Admin details including AdminID, AdminName etc.</param>
        /// <returns>Determinates whether the existing admin is updated.</returns>
        public override bool UpdateAdminDAL(Admin updateAdmin)
        {
            bool adminUpdated = false;
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            try
            {
                sqlConn.Open();
            }
            catch (Exception)
            {
                throw;
            }

            try
            {
                //creating object of sql Command
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "TeamB.UpdateAdmin";
                sqlcmd.Connection = sqlConn;
                sqlcmd.CommandType = CommandType.StoredProcedure;
                //passing parameters 
                sqlcmd.Parameters.AddWithValue("@adminId", updateAdmin.AdminID);
                sqlcmd.Parameters.AddWithValue("@adminname", updateAdmin.AdminName);
                sqlcmd.Parameters.AddWithValue("@email", updateAdmin.Email);



                int updated = Convert.ToInt32(sqlcmd.ExecuteScalar());
                if (updated > 0) { adminUpdated = true; }

            }
            catch (Exception)
            {
                throw;
            }
            return adminUpdated;
        }

        /// <summary>
        /// Updates admin's password based on Admin email.
        /// </summary>
        /// <param name="updateAdmin">Represents Admin details including AdminID, Password.</param>
        /// <returns>Determinates whether the existing admin's password is updated.</returns>
        public override bool UpdateAdminPasswordDAL(Admin updateAdmin)
        {
            bool passwordUpdated = false;
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            try
            {
                sqlConn.Open();
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "TeamB.UpdateAdminPassword";
                sqlcmd.Connection = sqlConn;
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@email", updateAdmin.Email);
                sqlcmd.Parameters.AddWithValue("@NewPassword", updateAdmin.Password);

                int updated = Convert.ToInt32(sqlcmd.ExecuteScalar());
                if (updated >0) { passwordUpdated = true; }

            }
            catch (Exception)
            {
                throw;
            }
            return passwordUpdated;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}

